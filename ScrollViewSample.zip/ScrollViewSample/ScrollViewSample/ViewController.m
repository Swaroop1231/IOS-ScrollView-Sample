//  ViewController.m
//  ScrollViewSample
//  
//  Created by Varma Bhupatiraju on 5/15/13.
//  Copyright (c) 2013 Varma Bhupatiraju. All rights reserved.
//
 


#import "ViewController.h"
@interface ViewController ()

@end
@implementation ViewController
@synthesize scrollView;
@synthesize photosArray;
@synthesize HorizontalscrollView;
@synthesize pageContr;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    photosArray=[[NSMutableArray alloc]initWithObjects:@"01.png",@"02.png",@"03.png",@"10.png",@"11.png",@"12.png",@"20.png",@"21.png",@"30.png",@"31.png",@"40.png",@"50.png",@"51.png", nil];
    
   // [self.view addSubview:scrollView];
    HorizontalscrollView.hidden=YES;
    pageContr.numberOfPages=[photosArray count];
    [self createScrollView];
    
}

-(void)createScrollView

{   int  x=10;
    int y=10;
    
    for (int i=0; i<[photosArray count]; i++)
    {
        
            
     UIView *adView=[[UIView alloc]initWithFrame:CGRectMake(x, y, 80, 80)];
    adView.clipsToBounds=YES;
        
     UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
       
        imageView.image=[UIImage imageNamed:[photosArray objectAtIndex:i]];
        [adView addSubview:imageView];
               
        
        UIButton *imageButton=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
        [imageButton addTarget:self action:@selector(userImageClicked:) forControlEvents:UIControlEventTouchUpInside];
        imageButton.tag=i;
        
        
        [adView addSubview:imageButton];
        [self.scrollView addSubview:adView];

                
        if((i+1)%3==0)
        {
            x=10;
            y=y+95;
            
        }
        else 
        {
            x=x+105;
        }
        
    }
    
     NSLog(@"Y is %d",y);
    self.scrollView.contentSize=CGSizeMake(self.scrollView.frame.size.width, y+100);
       
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    CGFloat pageWidth = HorizontalscrollView.frame.size.width;
    int page = floor((HorizontalscrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    
    
    pageContr.currentPage=page;
    
}

-(IBAction)userImageClicked:(id)sender;
{
    
    scrollView.hidden=YES;
    HorizontalscrollView.hidden=NO;
    HorizontalscrollView.pagingEnabled=YES;
    int x=0;
    int y=0;
   
    for (int i=0; i<[photosArray count]; i++)
    {
        
        
        UIView *adView=[[UIView alloc]initWithFrame:CGRectMake(x, y, 320, 243)];
      //  adView.clipsToBounds=YES;
        
        UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 243)];
        
        imageView.image=[UIImage imageNamed:[photosArray objectAtIndex:i]];
        
        [adView addSubview:imageView];
        [self.HorizontalscrollView addSubview:adView];
        
        x=x+320;
               
        
    }
    
    NSLog(@"Y is %d",y);
       HorizontalscrollView.contentSize=CGSizeMake(x, HorizontalscrollView.frame.size.height);
    [HorizontalscrollView setContentOffset:CGPointMake([sender tag ]*320,0)];

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
