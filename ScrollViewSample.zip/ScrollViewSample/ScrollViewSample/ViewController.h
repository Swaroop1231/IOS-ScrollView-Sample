//
//  ViewController.h
//  ScrollViewSample
//
//  Created by Varma Bhupatiraju on 5/15/13.
//  Copyright (c) 2013 Varma Bhupatiraju. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIScrollViewDelegate>
{
    
    UIScrollView *scrollView;
    UIScrollView *HorizontalscrollView;
    UIPageControl *pageContr;
}

@property(nonatomic,strong) NSMutableArray *photosArray;
@property(nonatomic,strong) IBOutlet  UIScrollView *scrollView;
@property(nonatomic,strong) IBOutlet  UIScrollView *HorizontalscrollView;
@property(nonatomic,strong) IBOutlet  UIPageControl *pageContr;


-(void)createScrollView;
-(IBAction)userImageClicked:(id)sender;


@end
